import BSOffcanvas from 'bootstrap/js/src/offcanvas';

class Offcanvas extends BSOffcanvas {}

export { Offcanvas as default };
//# sourceMappingURL=offcanvas.js.map
