import BSDropdown from 'bootstrap/js/src/dropdown';

class Dropdown extends BSDropdown {}

export { Dropdown as default };
//# sourceMappingURL=dropdown.js.map
