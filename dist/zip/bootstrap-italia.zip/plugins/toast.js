import BSToast from 'bootstrap/js/src/toast';

class Toast extends BSToast {}

export { Toast as default };
//# sourceMappingURL=toast.js.map
