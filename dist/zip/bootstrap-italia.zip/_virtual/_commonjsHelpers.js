function createCommonjsModule(fn, module) {
	return module = { exports: {} }, fn(module, module.exports), module.exports;
}

export { createCommonjsModule };
//# sourceMappingURL=_commonjsHelpers.js.map
