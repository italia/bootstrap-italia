// bootstrap italia version variable
// useful to check for the current version
// eslint-disable-next-line no-unused-vars
const BOOTSTRAP_ITALIA_VERSION = '2.8.7';

export { BOOTSTRAP_ITALIA_VERSION as default };
//# sourceMappingURL=version.js.map
