// bootstrap italia version variable
// useful to check for the current version

const BOOTSTRAP_ITALIA_VERSION = '2.12.0';

export { BOOTSTRAP_ITALIA_VERSION as default };
//# sourceMappingURL=version.js.map
